#!/usr/bin/env python3

#import http.server
#import socketserver

import HTTPServer

# port = 80
#DIRECTORY = "web"

def main():
    HTTPServer.runHTTPServer()

if __name__ == "__main__":
    main()
